import csv
from datetime import datetime
import json
from pathlib import Path
import re
import tempfile
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import xlsxwriter
from project_chart import column_chart
from project_theme import project_theme
from summary_sheet import add_summary

HERE = Path(__file__).resolve().parent
LAYOUT = json.loads((HERE / 'layout.json').read_text(encoding='utf-8'))
NAVY, GRID, BLUE = '#0F4D92', '#D5D7DA', '#E8F0F8'


def load_table(directory, spec):
    path = directory / spec['csv']
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.reader(stream))
    if not rows or rows[0] != spec['headers']:
        raise ValueError(f'{path.name}: missing or reordered CSV headers')
    for index, row in enumerate(rows, 1):
        if len(row) != len(rows[0]):
            raise ValueError(f'{path.name}: inconsistent number of fields in row {index}')
    return rows


def dimensions(sheet, spec):
    sheet.hide_gridlines(2)
    sheet.set_row(0, 30)
    for first, last, width in spec['widths']:
        sheet.set_column(first, last, width)


def data_sheet(workbook, name, spec, rows):
    sheet = workbook.add_worksheet(name)
    dimensions(sheet, spec)
    header_width = spec['styled_header_columns']
    count = max(header_width, len(rows[0]))
    body = {'font_name': 'Arial', 'font_size': 8, 'font_scheme': '', 'valign': 'vcenter'}
    regular = workbook.add_format(body)
    header = dict(body, bold=True, font_color='white', bg_color=NAVY, text_wrap=True,
                  align='center', top=1, bottom=1, top_color=GRID, bottom_color=GRID)
    formats = []
    for column in range(count):
        props = header.copy()
        if column == 0:
            props.update(left=1, left_color=GRID)
        if column == header_width - 1:
            props.update(right=1, right_color=GRID)
        if name == 'GSEA_Summary' and 10 <= column <= 13:
            props['num_format'] = '0.0000' if column < 12 else '0.00E+00'
        if name == 'Gene_Union_712' and 12 <= column <= 17:
            props['num_format'] = '0.0000'
        formats.append(workbook.add_format(props) if column < header_width else regular)
    if spec['table'] and len(rows) >= 2 and len(rows) <= 10000:
        columns = [{'header': rows[0][i] if i < len(rows[0]) else f'Column{i+1}',
                    'header_format': formats[i]} for i in range(count)]
        sheet.add_table(0, 0, len(rows)-1, count-1, {
            'name': spec['table'], 'style': 'Table Style Medium 2', 'columns': columns})
    for row_id, row in enumerate(rows):
        for column in range(count):
            style = regular if row_id else formats[column]
            if column >= len(row):
                sheet.write_blank(row_id, column, None, style)
            else:
                result = sheet.write_string(row_id, column, row[column], style)
                if result != 0:
                    raise ValueError(f'{name}: failed to write row {row_id+1}, column {column+1}')
    if name == 'GSEA_Summary':
        sheet.conditional_format('K2:L21', {'type': '3_color_scale', 'min_type': 'min', 'mid_type': 'num',
            'mid_value': 0, 'max_type': 'max', 'min_color': '#9A4D8E', 'mid_color': '#FFFFFF', 'max_color': NAVY})


def text_sheet(workbook, name, spec, rows):
    sheet = workbook.add_worksheet(name)
    dimensions(sheet, spec)
    base = dict(font_name='Carlito', font_size=11, font_scheme='', border=1, border_color=GRID)
    head = workbook.add_format(dict(base, font_size=9, bold=True, font_color='white',
                                    bg_color=NAVY, align='center', valign='vcenter', text_wrap=True))
    wrap = name != 'Figures_Index'
    first = workbook.add_format(dict(base, bold=True, bg_color=BLUE, text_wrap=wrap))
    body = workbook.add_format(dict(base, text_wrap=wrap))
    for r, row in enumerate(rows):
        if name == 'Figure_Legends' and r:
            sheet.set_row(r, 62)
        for c, value in enumerate(row):
            style = head if r == 0 else first if c == 0 else body
            if isinstance(value, str):
                sheet.write_string(r, c, value, style)
            else:
                sheet.write_number(r, c, value, style)


def normalize(src, dest):
    with ZipFile(src) as zin, ZipFile(dest, 'w') as zout:
        strings = ET.fromstring(zin.read('xl/sharedStrings.xml'))
        shared = [''.join(t.text or '' for t in i.findall('.//{*}t')) for i in strings]
        def text_cell(match):
            value = shared[int(match[3])]
            start = match[1] + b' t="str"' + match[2][:-1]
            if value == '':
                return start + b'/>'
            return start + b'><v>' + escape(value).encode('utf-8') + b'</v></c>'
        sheet_names = list(LAYOUT)
        for name in sorted(zin.namelist()):
            data = zin.read(name)
            sheet_number = re.fullmatch(r'xl/worksheets/sheet(\d+)\.xml', name)
            if sheet_number:
                spec = LAYOUT[sheet_names[int(sheet_number[1])-1]]
                widths = {i+1: w for first, last, w in spec['widths'] for i in range(first,last+1)}
                def exact_width(m):
                    index = int(re.search(rb'min="(\d+)"', m[0])[1])
                    return re.sub(rb'width="[^"]+"', f'width="{widths[index]}"'.encode(), m[0])
                data = re.sub(rb'<col\s[^>]+/>', exact_width, data)
                data = re.sub(rb'(<c\b[^>]*?) t="s"([^>]*>)<v>([0-9]+)</v></c>', text_cell, data)
                data = re.sub(rb'(<cfvo type="(?:min|max)") val="0"', rb'\1', data)
            elif name == 'xl/workbook.xml':
                # V1 leaves the window settings and opening calculation mode to Excel.
                data = re.sub(rb'<bookViews>.*?</bookViews>', b'', data)
                data = re.sub(rb'<calcPr\b[^>]*/>', b'', data)
            elif name == 'xl/sharedStrings.xml':
                data = b'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="0" uniqueCount="0"/>'
            elif name == 'xl/styles.xml':
                data = data.replace(b'<family val="2"/>', b'').replace(b'<color theme="1"/>', b'')
            elif name == 'xl/charts/chart1.xml':
                data = column_chart(data)
            elif name == 'docProps/app.xml':
                data = re.sub(rb'<Application>.*?</Application>', f'<Application>XlsxWriter {xlsxwriter.__version__}</Application>'.encode(), data)
                data = re.sub(rb'<AppVersion>.*?</AppVersion>', b'', data)
            elif name == 'xl/theme/theme1.xml':
                data = project_theme()
            elif name == 'xl/drawings/drawing1.xml':
                data = re.sub(rb'<xdr:to>.*?</xdr:to>', b'<xdr:to><xdr:col>13</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>21</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>', data)
            info = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_DEFLATED
            zout.writestr(info, data, compresslevel=6)


def build(root, stage):
    dest = stage / '05_workbook/APR_Strict_GSEA_analysis.xlsx'
    dest.parent.mkdir(parents=True)
    reports = json.loads((HERE / 'report_rows.json').read_text(encoding='utf-8'))
    summary_layout = json.loads((HERE / 'summary_layout.json').read_text(encoding='utf-8'))
    with tempfile.TemporaryDirectory(dir=stage) as tmp:
        raw = Path(tmp) / 'draft.xlsx'
        options = {'tmpdir': tmp, 'strings_to_numbers': False, 'strings_to_urls': False,
                   'default_format_properties': {'font_name':'Carlito', 'font_size':11, 'font_scheme':''}}
        with xlsxwriter.Workbook(raw, options) as workbook:
            workbook.set_properties({'title':'APR Strict GSEA', 'author':'Tg-eIF5A project workflow', 'created':datetime(1980,1,1)})
            for name, spec in LAYOUT.items():
                if 'csv' in spec:
                    rows = load_table(root/'03_tables', spec)
                    data_sheet(workbook, name, spec, rows)
                    if name == 'GSEA_Summary':
                        if len(rows) < 6:
                            raise ValueError('gsea_summary.csv: the Summary formulas require at least five data rows')
                        gsea_rows = rows
                elif name == 'Summary':
                    add_summary(workbook, summary_layout, gsea_rows)
                else:
                    text_sheet(workbook, name, spec, reports[name])
        normalize(raw, dest)
    return dest
