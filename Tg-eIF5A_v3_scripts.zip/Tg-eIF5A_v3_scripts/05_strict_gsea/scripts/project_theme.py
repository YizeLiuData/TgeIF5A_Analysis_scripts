from xml.etree import ElementTree as ET

A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
ET.register_namespace('a', A)

def child(parent, tag, **attrs):
    return ET.SubElement(parent, '{%s}%s' % (A, tag), {k: str(v) for k, v in attrs.items()})

def placeholder(parent, modifiers=()):
    clr = child(parent, 'schemeClr', val='phClr')
    for name, value in modifiers:
        child(clr, name, val=value)

def solid(parent, modifiers=()):
    placeholder(child(parent, 'solidFill'), modifiers)

def gradient(parent, stops):
    node = child(parent, 'gradFill')
    stop_list = child(node, 'gsLst')
    for position, values in zip((0, 50000, 100000), stops):
        placeholder(child(stop_list, 'gs', pos=position), values)
    child(node, 'lin', ang=5400000, scaled=0)

def project_theme():
    root = ET.Element('{%s}theme' % A, name='Tg-eIF5A')
    elements = child(root, 'themeElements')
    colors = child(elements, 'clrScheme', name='Tg-eIF5A')
    for key, val, fallback in [('dk1','windowText','000000'),('lt1','window','FFFFFF')]:
        child(child(colors,key),'sysClr',val=val,lastClr=fallback)
    palette = {'dk2':'0E2841','lt2':'E8E8E8','accent1':'156082','accent2':'E97132',
               'accent3':'196B24','accent4':'0F9ED5','accent5':'A02B93','accent6':'4EA72E',
               'hlink':'467886','folHlink':'96607D'}
    for key, val in palette.items():
        child(child(colors,key),'srgbClr',val=val)
    fonts = child(elements,'fontScheme',name='Office')
    for key, name in [('majorFont','Calibri Light'),('minorFont','Calibri')]:
        grp=child(fonts,key)
        for script in ['latin','ea','cs']:
            child(grp,script,typeface=name)
    fmt=child(elements,'fmtScheme',name='Tg-eIF5A')
    fills=child(fmt,'fillStyleLst')
    solid(fills)
    gradient(fills,[
        [('tint',67000),('lumMod',110000),('satMod',105000)],
        [('tint',73000),('lumMod',105000),('satMod',103000)],
        [('tint',81000),('lumMod',105000),('satMod',109000)]])
    gradient(fills,[
        [('tint',94000),('lumMod',102000),('satMod',103000)],
        [('shade',100000),('lumMod',100000),('satMod',110000)],
        [('shade',78000),('lumMod',99000),('satMod',120000)]])
    lines=child(fmt,'lnStyleLst')
    for w in (12700,19050,25400):
        ln=child(lines,'ln',w=w)
        solid(ln)
        child(ln,'prstDash',val='solid')
    effects=child(fmt,'effectStyleLst')
    for i in range(3):
        lst=child(child(effects,'effectStyle'),'effectLst')
        if i==2:
            sh=child(lst,'outerShdw',blurRad=57150,dist=19050,dir=5400000)
            child(child(sh,'srgbClr',val='000000'),'alpha',val=63000)
    bg=child(fmt,'bgFillStyleLst')
    solid(bg)
    solid(bg,[('tint',95000),('satMod',170000)])
    gradient(bg,[
        [('tint',93000),('shade',98000),('lumMod',102000),('satMod',150000)],
        [('tint',98000),('shade',90000),('lumMod',103000),('satMod',130000)],
        [('shade',63000),('satMod',120000)]])
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)
