import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from xml.etree import ElementTree as ET

SCRIPTS=Path(__file__).resolve().parent
VENDOR=SCRIPTS.parent/'vendor'
sys.path[:0]=[str(SCRIPTS),str(VENDOR/'python')]
try:
    from workbook_writer import build, LAYOUT
    import xlsxwriter
except ImportError as err:
    raise SystemExit('Missing workbook dependency: '+str(err))
from archive_io import file_hash
from workbook_view import scan_workbook, inspect_summary, notice

BOOK=Path('05_workbook/APR_Strict_GSEA_analysis.xlsx')
QC=Path('06_qc')
PREVIEWS=QC/'workbook_previews'
REPORTS=(QC/'workbook_formula_scan.ndjson',QC/'workbook_summary_inspect.ndjson')
CONTENT=(BOOK,*REPORTS,*(PREVIEWS/(name.replace('_','-')+'.png') for name in LAYOUT))
RECEIPT=QC/'workbook_build.json'
OUTPUTS=(*CONTENT,RECEIPT)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(',',':')),encoding='utf-8')


def render_all(book, stage, node):
    errors, views = scan_workbook(book, True)
    if errors:
        raise ValueError('Spreadsheet error at ' + ', '.join(x['sheet']+'!'+x['address'] for x in errors[:10]))
    (stage/PREVIEWS).mkdir(parents=True)
    write_json(stage/REPORTS[0], notice())
    write_json(stage/REPORTS[1], inspect_summary(views['Summary']))
    with tempfile.TemporaryDirectory(dir=stage) as work:
        work=Path(work);fonts=VENDOR/'fonts'
        config=ET.Element('fontconfig')
        ET.SubElement(config,'dir').text=str(fonts)
        ET.SubElement(config,'cachedir').text=str(work/'font-cache')
        for name,substitute in [('Arial','Liberation Sans'),('Calibri','Carlito'),('sans-serif','Carlito')]:
            alias=ET.SubElement(config,'alias')
            ET.SubElement(alias,'family').text=name
            ET.SubElement(ET.SubElement(alias,'prefer'),'family').text=substitute
        cfg=work/'fonts.conf'
        ET.ElementTree(config).write(cfg,encoding='utf-8',xml_declaration=True)
        env={'PATH':os.defpath,'LANG':'C.UTF-8','TZ':'UTC','NODE_PATH':str(VENDOR/'node_modules'),
             'FONTCONFIG_FILE':str(cfg),'DISABLE_SYSTEM_FONTS_LOAD':'1','XDG_CACHE_HOME':str(work),'TMPDIR':str(work)}
        for name,model in views.items():
            write_json(work/'sheet.json', model)
            image=stage/PREVIEWS/(name.replace('_','-')+'.png')
            subprocess.run([node,str(SCRIPTS/'render_sheet.cjs'),str(work/'sheet.json'),str(image),
                            str(fonts),str(SCRIPTS/'preview_settings.json')],env=env,check=True)


def fingerprint(stage):
    digest=hashlib.sha256()
    for relative in OUTPUTS:
        digest.update(relative.as_posix().encode()+b'\0')
        digest.update(hashlib.sha256((stage/relative).read_bytes()).digest())
    return digest.hexdigest()


def publish(root, stage, transaction):
    versions=root/'.workbook-builds'
    versions.mkdir(exist_ok=True)
    pointer=root/'.workbook-current'
    dest=versions/fingerprint(stage)
    if not dest.exists():
        os.replace(stage,dest)
    if not pointer.is_symlink():
        previous=transaction/'previous'
        for relative in OUTPUTS:
            existing=root/relative
            if existing.is_file():
                (previous/relative).parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(existing,previous/relative)
        if previous.exists():
            prior=Path(tempfile.mkdtemp(prefix='imported-',dir=versions))
            prior.rmdir()
            os.replace(previous,prior)
            pointer.symlink_to(prior.relative_to(root))
    for relative in OUTPUTS:
        target=root/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        link=os.path.relpath(pointer/relative,target.parent)
        if target.is_symlink() and os.readlink(target)==link:
            continue
        temporary=transaction/'link'
        temporary.symlink_to(link)
        os.replace(temporary,target)
    switch=transaction/'switch'
    switch.symlink_to(dest.relative_to(root))
    os.replace(switch,pointer)


def main(root,node):
    root=root.resolve()
    lock=json.loads((SCRIPTS.parent/'runtime-lock.json').read_text())
    if xlsxwriter.__version__ != lock['writer']['XlsxWriter']:
        raise ValueError('XlsxWriter version differs from runtime-lock.json')
    renderer=json.loads((VENDOR/'node_modules/skia-canvas/package.json').read_text())
    if renderer['version'] != lock['node_modules']['skia-canvas']:
        raise ValueError('skia-canvas version differs from runtime-lock.json')
    for spec in LAYOUT.values():
        if 'csv' in spec and not (root/'03_tables'/spec['csv']).is_file():
            raise FileNotFoundError('Missing required input: '+spec['csv'])
    with (root/'.workbook.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(dir=root,prefix='.build-') as work:
            work=Path(work);stage=work/'outputs'
            inputs=work/'inputs'
            (inputs/'03_tables').mkdir(parents=True)
            fingerprints={}
            for spec in LAYOUT.values():
                if 'csv' not in spec:
                    continue
                relative=Path('03_tables')/spec['csv']
                shutil.copyfile(root/relative,inputs/relative)
                fingerprints[relative.as_posix()]=file_hash(inputs/relative)
            book=build(inputs,stage)
            render_all(book,stage,node)
            if any(file_hash(root/name)!=v for name,v in fingerprints.items()):
                raise ValueError('A source CSV changed during the workbook build. Retry with stable inputs.')
            write_json(stage/RECEIPT,{'inputs':fingerprints,'outputs':{p.as_posix():file_hash(stage/p) for p in CONTENT}})
            publish(root,stage,work)
    print(json.dumps({'outPath':str(root/BOOK),'sheets':list(LAYOUT)},ensure_ascii=False))


if __name__=='__main__':
    try:
        main(Path(sys.argv[1]),sys.argv[2])
    except (OSError,ValueError,subprocess.CalledProcessError,ImportError) as error:
        print('Workbook build failed: '+str(error),file=sys.stderr)
        sys.exit(1)
