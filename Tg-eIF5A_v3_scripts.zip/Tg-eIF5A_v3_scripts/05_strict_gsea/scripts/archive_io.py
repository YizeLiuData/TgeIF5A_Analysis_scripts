import csv
from hashlib import sha256
import os
from pathlib import Path
import shutil
import tempfile
from zipfile import ZIP_DEFLATED,ZipFile,ZipInfo


def file_hash(path):
    h=sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def published(root):
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if '__pycache__' in relative.parts or ('vendor' not in relative.parts and any(x.startswith('.') for x in relative.parts)):
            continue
        if any(v=='node_modules' and (i==0 or relative.parts[i-1]!='vendor') for i,v in enumerate(relative.parts)):
            continue
        if path.is_file() and path.suffix not in ('.pyc','.pyo'):
            yield relative.as_posix(),path


def atomic_text(path, text):
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',newline='',dir=path.parent,delete=False) as tmp:
        tmp.write(text)
    os.replace(tmp.name,path)


def inventory(root):
    roles={'01_inputs':'scientific input','02_scripts':'source','03_tables':'analysis data','04_figures':'scientific figure',
           '05_workbook':'workbook','06_qc':'quality check','vendor':'public dependency'}
    rows=[]
    for name,p in published(root):
        if name in ('MANIFEST.tsv','checksums.sha256'):continue
        rows.append((name,roles.get(name.split('/')[0],'project file'),p.stat().st_size,file_hash(p)))
    import io
    buffer=io.StringIO(newline='');w=csv.writer(buffer,delimiter='\t',lineterminator='\n')
    w.writerow(['relative_path','role','size_bytes','sha256']);w.writerows(rows)
    atomic_text(root/'MANIFEST.tsv',buffer.getvalue())
    atomic_text(root/'checksums.sha256',''.join(f'{h}  {name}\n' for name,_,_,h in rows))


def archive(destination, entries):
    destination=Path(destination)
    destination.parent.mkdir(exist_ok=True,parents=True)
    fd,tmp=tempfile.mkstemp(dir=destination.parent,prefix='.zip-');os.close(fd)
    try:
        with ZipFile(tmp,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
            for name,source in sorted(entries,key=lambda v:v[0]):
                info=ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
                info.external_attr=(0o100755 if name.endswith('.sh') else 0o100644)<<16
                info.compress_type=ZIP_DEFLATED;info._compresslevel=6
                with Path(source).open('rb') as inp,z.open(info,'w') as out:
                    shutil.copyfileobj(inp,out,length=1024*1024)
        os.replace(tmp,destination)
    finally:
        Path(tmp).unlink(missing_ok=True)
    return destination
