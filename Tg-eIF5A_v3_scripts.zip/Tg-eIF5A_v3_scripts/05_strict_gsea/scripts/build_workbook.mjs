import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.env.APR_GSEA_ROOT || path.join(directory, '..'));
const command = process.env.APR_PYTHON || 'python3';
const args = ['-I', '-S', '-B', path.join(directory, 'build_workbook.py'), root, process.execPath];
const result = spawnSync(command, args, { stdio: 'inherit' });
if (result.error) console.error(result.error.message);
process.exitCode = result.status ?? 1;
