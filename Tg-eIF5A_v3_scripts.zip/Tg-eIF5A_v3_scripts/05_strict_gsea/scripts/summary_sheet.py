from xlsxwriter.utility import xl_cell_to_rowcol

NAVY='#0F4D92'
BLUE='#E8F0F8'
TEAL='#E8F5F6'
GRAY='#F3F4F6'
GRID='#D5D7DA'
FONT='Carlito'
WIDTHS=[25,16,16,42,16,16,16,16]

def formats(workbook):
    grid=dict(border=1,border_color=GRID)
    properties={
      'title':dict(bg_color=NAVY,font_name='Arial',font_size=17,bold=True,font_color='white',valign='vcenter'),
      'finding':dict(bg_color='#F2E9F3',font_color='#9A4D8E',bold=True,text_wrap=True,valign='vcenter'),
      'scope':dict(bg_color='#FFF4DE',font_color='#7A4E00',text_wrap=True,valign='vcenter'),
      'head':dict(grid,bg_color=NAVY,font_color='white',bold=True,align='center'),
      'label':dict(grid,bg_color=BLUE,bold=True), 'cell':grid,
      'gray_label':dict(grid,bg_color=GRAY,bold=True),'number':dict(grid,num_format='0.0000'),
    }
    for label,fill in [('b',BLUE),('c',TEAL)]:
        for fmt,code in [('gen','General'),('dec','0.0000'),('exp','0.00E+00')]:
            properties[label+fmt]=dict(grid,bg_color=fill,num_format=code)
    result={}
    for k,props in properties.items():
        base=dict(font_name=FONT,font_size=11,font_scheme='')
        result[k]=workbook.add_format(base | props)
    return result

def summary_style(r,c):
    if r in (7,18) and c<=4:
        return 'head'
    if 8<=r<=15 and c<=4:
        if c==1:return 'label'
        if c==4:return 'cell'
        numeric='dec' if 10<=r<=11 else 'exp' if 12<=r<=13 else 'gen'
        return ('b' if c==2 else 'c')+numeric
    if 19<=r<=21 and c<=4:
        return {1:'gray_label',2:'cell',3:'number',4:'cell'}[c]
    return None

def add_summary(workbook, layout, rows):
    sh=workbook.add_worksheet('Summary')
    sh.hide_gridlines(2)
    sh.set_default_row(15)
    for col,width in enumerate(WIDTHS):
        sh.set_column(col,col,width)
    fmt=formats(workbook)
    vals=layout['values']
    for box,first,style in [('A1:H2','A1','title'),('A4:H5','A4','finding'),('A24:H27','A24','scope')]:
        sh.merge_range(box,vals[first],fmt[style])
    for address,value in vals.items():
        if address in ('A1','A4','A24'):continue
        ri,ci=xl_cell_to_rowcol(address)
        style=fmt.get(summary_style(ri+1,ci+1))
        if isinstance(value,str):sh.write_string(ri,ci,value,style)
        else:sh.write_number(ri,ci,value,style)
    for address,formula in layout['formulas'].items():
        target=formula.split('!',1)[1];tr,tc=xl_cell_to_rowcol(target)
        value=rows[tr][tc]
        ri,ci=xl_cell_to_rowcol(address)
        sh.write_formula(ri,ci,formula,fmt.get(summary_style(ri+1,ci+1)),value)
    chart = workbook.add_chart({'type': 'column', 'name': 'Chart'})
    chart.add_series({
        'name': 'NES',
        'categories': "='Summary'!$J$8:$J$9",
        'values': "='Summary'!$K$8:$K$9",
    })
    chart.set_title({'name': 'Primary normalized enrichment scores'})
    sh.insert_chart('F7',chart,{'object_position':1})

