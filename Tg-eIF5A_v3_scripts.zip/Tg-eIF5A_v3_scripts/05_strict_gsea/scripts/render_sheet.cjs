'use strict';
const fs = require('node:fs');
const path = require('node:path');

const [modelFile, target, fontDirectory, settingsFile] = process.argv.slice(2);
const model = JSON.parse(fs.readFileSync(modelFile, 'utf8'));
const opts = settingsFile ? JSON.parse(fs.readFileSync(settingsFile, 'utf8')) : {};
const engine = require('skia-canvas');
function createCanvas(width, height) {
  const result = new engine.Canvas(width, height);
  result.gpu = false;
  return result;
}
const aliases = {};
function loadFace(family, file, weight) {
  const alias = 'Project_' + family.replaceAll(' ', '') + '_' + weight;
  const fontPath=path.join(fontDirectory,file);
  engine.FontLibrary.use(alias, [fontPath]);
  const ok = engine.FontLibrary.has(alias);
  if (!ok) throw new Error('Missing font face '+file);
  aliases[family+'_'+weight]=alias;
}
const installed=[
  ['Carlito','Carlito-Regular.ttf','Regular'],['Carlito','Carlito-Bold.ttf','Bold'],
  ['Arial','LiberationSans-Regular.ttf','Regular'],['Arial','LiberationSans-Bold.ttf','Bold']
];
for(const row of installed)loadFace(...row);
if(opts.fontFiles) for(const row of opts.fontFiles)loadFace(...row);
function colLabel(index) {
  let n=index+1, label='';
  while(n){ n--; label=String.fromCharCode(65+n%26)+label; n=Math.floor(n/26); }
  return label;
}
function address(s) {
  const [,letters,row] = /^([A-Z]+)([0-9]+)$/.exec(s);
  let col=0;for(const ch of letters)col=26*col+ch.charCodeAt(0)-64;
  return [col-1, Number(row)-1];
}
function cumulative(vals,first,scale) {
  let pos=first;return [first,...vals.map(v=>(pos+=v*scale))];
}
const x=cumulative(model.cols,40,10);
const y=cumulative(model.rowHeights,20,96/72);
const [cw,ch]=model.size;
function fitPositions(values, size, header) {
  if(Math.abs(values.at(-1)-size) < 1) return;
  const scale=(size-header)/(values.at(-1)-header);
  for(let i=1;i<values.length;i++) values[i]=header+(values[i]-header)*scale;
}
fitPositions(x,cw,40);
fitPositions(y,ch,20);
const canvas=createCanvas(cw,ch),ctx=canvas.getContext('2d');
const body=opts.bodyFont||'Carlito',heading=opts.headerFont||body;
function setFont(name,size,bold=false){
  const face=aliases[name+'_'+(bold?'Bold':'Regular')];
  if(!face)throw new Error('Unavailable font: '+name);
  ctx.font=size+'px "'+face+'"';
}
function fill(x0,y0,x1,y1,color) {
  ctx.fillStyle=color;ctx.fillRect(x0,y0,x1-x0,y1-y0);
}
function rule(x0,y0,x1,y1,color,width=1,dash=[]){
  ctx.save();ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);
  ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.stroke();ctx.restore();
}
function text(s,x0,y0,color,align='left'){
  ctx.fillStyle=color;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(s,x0,y0);
}
fill(0,0,cw,ch,'#FFFFFF');
const horizontalHeader=20,verticalHeader=40;
function drawHeadings(){
  const size=opts.headerSize||12;
  const headerOff=opts.headerY??0;
  setFont(heading,size);
  function tile(l,t,r,b,label){
    fill(l,t,r,b,'#F5F5F5');
    ctx.strokeStyle=opts.headerBorder||'rgba(204,204,204,0.5)';
    ctx.lineWidth=1;ctx.strokeRect(l,t,r-l,b-t);
    if(label!=='')text(label,(l+r)/2,(t+b)/2+headerOff,'#444444','center');
  }
  for(let c=0;c<model.cols.length;c++)tile(x[c],0,x[c+1],horizontalHeader,colLabel(c));
  for(let r=0;r<model.rowHeights.length;r++)tile(0,y[r],verticalHeader,y[r+1],String(r+1));
  tile(0,0,verticalHeader,horizontalHeader,'');
}
const merged=new Map(),covered=new Set();
for(const area of model.merges) {
  const [start,end]=area.split(':');const [c0,r0]=address(start),[c1,r1]=address(end);
  merged.set(start,[c1,r1]);
  for(let rr=r0;rr<=r1;rr++)for(let cc=c0;cc<=c1;cc++){
    const name=colLabel(cc)+(rr+1);if(name!==start)covered.add(name);
  }
}
const conditionalColors = new Map();
for (const scale of (model.colorScales || [])) {
  const [start, end] = scale.range.split(':').map(address);
  const entries = [];
  for (const [key, cell] of Object.entries(model.cells)) {
    const [c, r] = address(key);
    if (c < start[0] || c > end[0] || r < start[1] || r > end[1] || cell.v == null || cell.v === '') continue;
    const value = Number(cell.v);
    if (Number.isFinite(value)) entries.push([key, value]);
  }
  if (!entries.length) continue;
  const numbers = entries.map(x => x[1]), low = Math.min(...numbers), high = Math.max(...numbers);
  const rgb = scale.colors.map(hex => [0, 2, 4].map(i => parseInt(hex.slice(i, i+2), 16)));
  for (const [key, value] of entries) {
    const lo = value <= scale.middle, i = lo ? 0 : 1;
    const a = lo ? low : scale.middle, b = lo ? scale.middle : high;
    const t = Math.max(0, Math.min(1, (value-a)/(b-a || 1)));
    const color = rgb[i].map((v,k) => Math.round(v+(rgb[i+1][k]-v)*t));
    conditionalColors.set(key, 'rgb('+color.join(',')+')');
  }
}

const boxes=[];
for(const [a,cell] of Object.entries(model.cells)){
  const [c,r]=address(a);if(c>=model.cols.length||r>=model.rowHeights.length||covered.has(a))continue;
  const [lastCol,lastRow]=merged.get(a)||[c,r];
  const box=[x[c],y[r],x[lastCol+1],y[lastRow+1]];
  const style=model.styles[cell.style];boxes.push({cell,style,box,a});

}
function display(cell,style) {
  const v=cell.v;
  if(typeof v!=='string')return '';
  const f=Number(v);
  if(v!=='' && Number.isFinite(f) && (cell.f || cell.type==='n')){
    if(style.fmt==='0.0000')return f.toFixed(4);
    if(style.fmt==='0.00E+00'){
      const [m,e]=f.toExponential(2).split('e');
      return m+'E'+(Number(e)<0?'-':'+')+String(Math.abs(Number(e))).padStart(2,'0');
    }
  }
  return v;
}
function wrapped(s,width){
  const result=[];
  for(const paragraph of s.split('\n')){
    let line='';
    for(const word of paragraph.split(' ')){
      const trial=line ? line+' '+word : word;
      if(line && ctx.measureText(trial).width>width){result.push(line);line=word;} else line=trial;
    }
    result.push(line);
  }
  return result;
}
for(const {cell,style,box,a} of boxes){
  const [l,t,r,b]=box;
  const row=address(a)[1];
  const band=model.table && row>0 && row%2===1;
  if(style.fill || cell.v!=null || band)fill(l,t,r,b,conditionalColors.get(a)||style.fill||(band?'#C1E5F5':'#FFFFFF'));
  const sides={left:[l,t,l,b],right:[r,t,r,b],top:[l,t,r,t],bottom:[l,b,r,b]};
  for(const [edge,[weight,color]] of Object.entries(style.border))rule(...sides[edge],color,1);
}
for(const {cell,style,box,a} of boxes){
  if(cell.v==null)continue;
  const [l,t,r,b]=box;
  const isTitle=model.chart && style.font==='Arial';
  const fontName=isTitle?(opts.titleFont||'Arial'):body;
  const size=style.pt*96/72*(isTitle?(opts.titleScale||1):(opts.textScale||1));
  setFont(fontName,size,style.bold);
  const pad=opts.pad??2;
  const align=style.h==='center'?'center':style.h==='right'||(style.h==='general'&&cell.type==='n')?'right':'left';
  const xx=align==='left'?l+pad:align==='right'?r-pad:(r+l)/2;
  const lines=style.wrap?wrapped(display(cell,style),r-l-2*pad):[display(cell,style)];
  const spacing=size*(opts.lineHeight||1.2);
  const yy=(b+t)/2-(lines.length-1)*spacing/2+(isTitle?(opts.titleY??0):(opts.textY??0));
  ctx.save();ctx.beginPath();ctx.rect(l,t,r-l,b-t);ctx.clip();
  for(let i=0;i<lines.length;i++)text(lines[i],xx,yy+i*spacing,style.ink,align);
  ctx.restore();
}
function niceStep(range) {
  const req=range/4,p=Math.pow(10,Math.floor(Math.log10(req)));
  const m=req/p;
  return (m<=1?1:m<=2?2:m<=5?5:10)*p;
}
function drawChart(){
  const g=model.chart;const [c0,r0,c1,r1]=g.anchor,L=x[c0],T=y[r0],R=x[c1],B=y[r1];
  fill(L,T,R,B,'#FFFFFF');
  ctx.strokeStyle='#D9D9D9';ctx.lineWidth=1;ctx.strokeRect(L+0.5,T+0.5,R-L-1,B-T-1);
  const chartFont=opts.chartFont||body;
  setFont(chartFont,opts.chartSize||18);text(g.title,(L+R)/2,T+(opts.chartTitleY??16),'#000000','center');
  let lo=Math.min(...g.values),hi=Math.max(...g.values);
  const step=niceStep((hi-lo)||Math.max(1,Math.abs(hi)*.1));
  const min=Math.floor((lo-.03*(hi-lo))/step)*step;
  const max=Math.ceil((hi+.15*(hi-lo))/step)*step+step;
  const left=L+42,right=R-19,top=T+52,bottom=B-6;
  const yy=v=>bottom-(v-min)/(max-min)*(bottom-top);
  setFont(chartFont,opts.axisSize||10);
  const n=Math.round((max-min)/step);
  for(let i=0;i<=n;i++){
    const v=min+i*step,h=yy(v);
    if(i<n)rule(left,h,right,h,'#CFCFCF',1,[4,3]);
    text(String(Number(v.toPrecision(8))),left-6,h,'#666666','right');
  }
  const inc=(right-left)/g.values.length;
  const base=yy(Math.min(Math.max(0,min),max));
  for(let i=0;i<g.values.length;i++){
    const mid=left+inc*(i+.5),v=yy(g.values[i]),w=inc*0.4;
    rule(mid,top,mid,bottom,'#CFCFCF',1,[4,3]);
    text(g.categories[i],mid,top-11,'#666666','center');
    ctx.fillStyle=g.color;
    const upper=Math.min(base,v),lower=Math.max(base,v);
    ctx.beginPath();ctx.roundRect(mid-w/2,upper,w,lower-upper,base<v?[0,0,2,2]:[2,2,0,0]);ctx.fill();
  }
}
if (model.chart) drawChart();
drawHeadings();
fs.writeFileSync(target, canvas.toBufferSync('png'));
