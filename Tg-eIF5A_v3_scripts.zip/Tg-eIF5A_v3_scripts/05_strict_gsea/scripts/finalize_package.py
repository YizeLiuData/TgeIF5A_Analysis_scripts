import argparse
import csv
from decimal import Decimal,ROUND_DOWN
import fcntl
import json
import math
import os
from pathlib import Path
import struct
import sys
import tempfile
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parent/'vendor/python')]
from archive_io import archive,file_hash,inventory,published,atomic_text
from build_workbook import BOOK,CONTENT,LAYOUT,PREVIEWS,RECEIPT,REPORTS
from workbook_view import scan_workbook,notice,inspect_summary
from pypdf import PdfReader,PdfWriter

FIGURES=['Figure1_main_GSEA_curves','Figure2_GSEA_robustness','Figure3_shared_unique_GSEA',
         'Figure4_leading_edge_comparison','Figure5_leading_edge_heatmap']


def validate(root):
    hits,views=scan_workbook(root/BOOK,True)
    if hits:
        raise ValueError('Spreadsheet error at '+', '.join(i['sheet']+'!'+i['address'] for i in hits[:10]))
    if list(views)!=list(LAYOUT):
        raise ValueError('Unexpected worksheet order or missing sheets')
    actual=(root/REPORTS[0]).read_text()
    if json.loads(actual)!=notice():
        raise ValueError('The current formula scan contains errors')
    if json.loads((root/REPORTS[1]).read_text())!=inspect_summary(views['Summary']):
        raise ValueError('Summary inspection is stale')
    receipt=json.loads((root/RECEIPT).read_text())
    expected_inputs={'03_tables/'+s['csv'] for s in LAYOUT.values() if 'csv' in s}
    if set(receipt['inputs'])!=expected_inputs or set(receipt['outputs'])!={p.as_posix() for p in CONTENT}:
        raise ValueError('Incomplete workbook build receipt')
    for name,h in {**receipt['inputs'],**receipt['outputs']}.items():
        if file_hash(root/name)!=h:
            raise ValueError('Stale or changed workbook input/output: '+name)
    for name,spec in LAYOUT.items():
        with (root/PREVIEWS/(name.replace('_','-')+'.png')).open('rb') as f:head=f.read(24)
        if head[:8]!=b'\x89PNG\r\n\x1a\n' or list(struct.unpack('>II',head[16:24]))!=spec['preview']['size']:
            raise ValueError('Invalid worksheet preview: '+name)
    with (root/'03_tables/gsea_summary.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
    tested=[r for r in rows if r['set_id'] in ('WT_TEST_Strict','Q_CTR_Strict')]
    if len(tested)!=8 or any(r['direction']!='WT ctr' or float(r['NES'])>=0 for r in tested):
        raise ValueError('Scientific sensitivity checks failed')
    primary=[r for r in tested if r['background']=='protein_coding' and r['metric']=='signed_logp']
    expected={'WT_TEST_Strict':(298,-.6230592715278095,-1.863641876143764,102),'Q_CTR_Strict':(695,-.6730595359593867,-2.1347237580020493,285)}
    if {r['set_id'] for r in primary}!=set(expected):raise ValueError('Primary comparisons missing')
    results=[]
    for row in primary:
        n,es,nes,leading=expected[row['set_id']]
        if int(row['gene_set_matched_n'])!=n or int(row['leading_edge_n'])!=leading or abs(float(row['ES'])-es)>1e-10 or abs(float(row['NES'])-nes)>1e-10 or float(row['BH_q_primary_pair'])>=.001:
            raise ValueError('Primary check failed: '+row['set_id'])
        probability=lambda k:float(Decimal(row[k]).quantize(Decimal('1e-16'),rounding=ROUND_DOWN))
        results.append({'set_id':row['set_id'],'gene_set_matched_n':n,'ES':float(row['ES']),'NES':float(row['NES']),
            'empirical_P':probability('empirical_P'),'BH_q_primary_pair':probability('BH_q_primary_pair'),
            'direction':row['direction'],'leading_edge_n':leading})
    for stem in FIGURES:
        for ext in ('svg','pdf','tiff','png'):
            path=root/'04_figures'/(stem+'.'+ext)
            if not path.is_file() or path.stat().st_size==0:raise ValueError('Missing scientific figure '+path.name)
    return {'status':'PASSED','primary_results':results,'sensitivity_analyses_all_WT_ctr':True,'figures':5,
            'formats_per_figure':['svg','pdf','tiff','png'],'workbook_sheets':sorted(LAYOUT),'formula_errors':0}


def finalize(root,zip_path=None):
    with (root/'.workbook.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        result=validate(root)
        writer=PdfWriter()
        for stem in FIGURES:
            for page in PdfReader(root/'04_figures'/(stem+'.pdf')).pages:writer.add_page(page)
        with tempfile.NamedTemporaryFile(dir=root/'04_figures',delete=False) as out:
            writer.write(out)
        os.replace(out.name,root/'04_figures/APR_Strict_GSEA_all_figures.pdf')
        result['combined_figure_pdf_pages']=len(writer.pages)
        atomic_text(root/'06_qc/output_validation.json',json.dumps(result,ensure_ascii=False,indent=2))
        inventory(root)
        if zip_path:
            archive(zip_path,(('APR_Strict_GSEA/'+n,p) for n,p in published(root)))
        return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(os.getenv('APR_GSEA_ROOT',HERE.parent)))
    parser.add_argument('--zip',type=Path)
    parser.add_argument('--validate-only',action='store_true')
    args=parser.parse_args();root=args.root.resolve()
    try:
        if args.validate_only:validate(root);print('Validated workbook, checks, previews and scientific results.')
        else:
            target=(args.zip or root.parent/'APR_Strict_GSEA_reproducible_package.zip').resolve()
            finalize(root,target);print(target)
    except (OSError,ValueError,KeyError) as e:
        raise SystemExit('Packaging failed: '+str(e))
