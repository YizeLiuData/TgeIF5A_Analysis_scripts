from copy import deepcopy
from xml.etree import ElementTree as ET

CHART = 'http://schemas.openxmlformats.org/drawingml/2006/chart'
DRAW = 'http://schemas.openxmlformats.org/drawingml/2006/main'
ET.register_namespace('c', CHART)
ET.register_namespace('a', DRAW)


def child(parent, name, ns=CHART, **attrs):
    return ET.SubElement(parent, f'{{{ns}}}{name}', attrs)


def line_style(parent, color, dash):
    properties = child(parent, 'spPr')
    line = child(properties, 'ln', DRAW, w='9525')
    child(child(line, 'solidFill', DRAW), 'srgbClr', DRAW, val=color)
    child(line, 'prstDash', DRAW, val=dash)


def axis(plot, kind, own, cross):
    category = kind == 'catAx'
    axis_node = child(plot, kind)
    child(axis_node, 'axId', val=own)
    child(child(axis_node, 'scaling'), 'orientation', val='minMax')
    child(axis_node, 'delete', val='0')
    child(axis_node, 'axPos', val='b' if category else 'l')
    line_style(child(axis_node, 'majorGridlines'), 'CCCCCC', 'dash')
    child(axis_node, 'numFmt', formatCode='0.0' if category else 'General')
    child(axis_node, 'majorTickMark', val='none')
    child(axis_node, 'minorTickMark', val='none')
    if category:
        child(axis_node, 'tickLblPos', val='nextTo')
    child(axis_node, 'crossAx', val=cross)
    if not category:
        child(axis_node, 'crossBetween', val='between')


def column_chart(source):
    template = ET.fromstring(source)
    original = template.find('.//{*}barChart')
    axis_ids = [item.get('val') for item in original.findall('{*}axId')]
    heading = ''.join(t.text or '' for t in template.findall('.//{*}title//{*}t'))
    space = ET.Element(f'{{{CHART}}}chartSpace')
    child(space, 'lang', val='en-US')
    child(space, 'roundedCorners', val='0')
    chart = child(space, 'chart')
    title = child(chart, 'title')
    rich = child(child(title, 'tx'), 'rich')
    child(rich, 'bodyPr', DRAW)
    child(rich, 'lstStyle', DRAW)
    paragraph = child(rich, 'p', DRAW)
    child(child(paragraph, 'r', DRAW), 't', DRAW).text = heading
    child(title, 'overlay', val='0')
    plot = child(chart, 'plotArea')
    bars = child(plot, 'barChart')
    child(bars, 'barDir', val='col')
    child(bars, 'varyColors', val='0')
    series = child(bars, 'ser')
    fresh = original.find('{*}ser')
    for name in ('idx', 'order', 'tx'):
        series.append(deepcopy(fresh.find('{*}' + name)))
    for name, reference_type, cache_type in (
        ('cat', 'strRef', 'strCache'),
        ('val', 'numRef', 'numCache'),
    ):
        reference = child(child(series, name), reference_type)
        child(reference, 'f').text = fresh.findtext('{*}' + name + '/*/{*}f')
        cache = child(reference, cache_type)
        if name == 'val':
            child(cache, 'formatCode').text = 'General'
        child(cache, 'ptCount', val='0')
    for number in axis_ids:
        child(bars, 'axId', val=number)
    axis(plot, 'catAx', axis_ids[0], axis_ids[1])
    axis(plot, 'valAx', axis_ids[1], axis_ids[0])
    child(chart, 'plotVisOnly', val='1')
    line_style(space, 'D9D9D9', 'solid')
    return ET.tostring(space, encoding='utf-8', xml_declaration=True)
