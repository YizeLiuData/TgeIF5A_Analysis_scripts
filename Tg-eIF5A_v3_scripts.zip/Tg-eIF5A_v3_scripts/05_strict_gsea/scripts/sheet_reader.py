from zipfile import ZipFile
from xml.etree import ElementTree as E
from pathlib import PurePosixPath
import posixpath,re,json,sys

M='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
C='http://schemas.openxmlformats.org/drawingml/2006/chart'
def loc(t):
 return t.tag.rsplit('}',1)[-1]
def tag(e,name):
 return e.find('{*}'+name) if e is not None else None
def val(e,name,key='val',default=None):
 f=tag(e,name);return f.get(key,default) if f is not None else default
def xml(z,n):
 return E.fromstring(z.read(n))
def rmap(z,name):
 root=PurePosixPath(name);rels=str(root.parent/'_rels'/(root.name+'.rels'))
 return {e.get('Id'):e.get('Target').lstrip('/') if e.get('Target','').startswith('/') else posixpath.normpath(posixpath.join(str(root.parent),e.get('Target'))) for e in xml(z,rels)}
def shared(z):
 if 'xl/sharedStrings.xml' not in z.namelist():return []
 return [''.join(t.text or '' for t in item.findall('.//{*}t')) for item in xml(z,'xl/sharedStrings.xml')]
def cells(sheet,ss):
 o={}
 for c in sheet.findall('.//{*}c'):
  typ=c.get('t','n');v=c.findtext('{*}v');f=c.findtext('{*}f')
  if typ=='s' and v is not None:typ='text';v=ss[int(v)]
  elif typ=='inlineStr':typ='text';v=''.join(k.text or '' for k in c.findall('.//{*}t'))
  o[c.get('r')]={'type':typ,'v':v,'f':f,'style':int(c.get('s',0))}
 return o

def rgb(e,fallback):
 if e is None:return fallback
 if e.get('rgb'):return '#'+e.get('rgb')[-6:]
 return fallback
def make_styles(styles):
 formats={int(n.get('numFmtId')):n.get('formatCode') for n in styles.findall('.//{*}numFmt')}
 fills=list(tag(styles,'fills'));fonts=list(tag(styles,'fonts'));borders=list(tag(styles,'borders'));result=[]
 for xf in tag(styles,'cellXfs'):
  font=fonts[int(xf.get('fontId',0))];fill=fills[int(xf.get('fillId',0))];border=borders[int(xf.get('borderId',0))]
  a=tag(xf,'alignment');p=tag(fill,'patternFill');edges={}
  for k in ['left','right','top','bottom']:
   d=tag(border,k)
   if d is not None and d.get('style'):edges[k]=[d.get('style'),rgb(tag(d,'color'),'#000000')]
  result.append({'font':val(font,'name',default='Carlito'),'pt':float(val(font,'sz',default=11)),
   'ink':rgb(tag(font,'color'),'#000000'),'bold':tag(font,'b') is not None,'fill':rgb(tag(p,'fgColor'),None) if p is not None and p.get('patternType')=='solid' else None,
   'border':edges,'fmt':formats.get(int(xf.get('numFmtId','0')),'General'),'h':a.get('horizontal','general') if a is not None else 'general',
   'vertical':a.get('vertical','bottom') if a is not None else 'bottom','wrap':a.get('wrapText')=='1' if a is not None else False})
 return result

def make_model(file_path):
 with ZipFile(file_path) as z:
  wb=xml(z,'xl/workbook.xml');names={e.get('name'):rmap(z,'xl/workbook.xml')[e.get('{%s}id'%R)] for e in wb.findall('.//{*}sheet')}
  sh=xml(z,names['Summary']);ss=shared(z);cs=cells(sh,ss);styles=make_styles(xml(z,'xl/styles.xml'))
  colors=[]
  theme=xml(z,'xl/theme/theme1.xml')
  for cc in theme.findall('.//{*}clrScheme'):
   colors=[next(iter(e)).get('val') for e in cc]
  cols=[8.43]*13
  for c in sh.findall('.//{*}col'):
   for i in range(int(c.get('min'))-1,min(13,int(c.get('max')))):
    cols[i]=float(c.get('width'))
  hh=[float(tag(sh,'sheetFormatPr').get('defaultRowHeight',15))]*27
  for row in sh.findall('.//{*}row'):
   if row.get('ht') and int(row.get('r'))<=len(hh):hh[int(row.get('r'))-1]=float(row.get('ht'))
  drawpath=rmap(z,names['Summary'])[tag(sh,'drawing').get('{%s}id'%R)];draw=xml(z,drawpath)
  chref=draw.findall('.//{*}chart')[0];ch=xml(z,rmap(z,drawpath)[chref.get('{%s}id'%R)]);bar=ch.findall('.//{*}barChart')[0];ser=tag(bar,'ser')
  refs=[f.text for f in ser.findall('.//{*}f')];refs=[f for f in refs if ':' in f]
  categories=[];values=[]
  for dest,ref in zip((categories,values),refs):
   beg,end=ref.split('!')[1].replace('$','').split(':');col=re.match('[A-Z]+',beg)[0]
   for row in range(int(beg[len(col):]),int(end[len(col):])+1):
    dest.append(cs[col+str(row)]['v'])
  frm=draw.find('.//{*}from');to=draw.find('.//{*}to')
  anchor=[int(k.findtext('{*}'+key)) for k in (frm,to) for key in ('col','row')]
  chart={'title':''.join(t.text or '' for t in tag(tag(ch,'chart'),'title').findall('.//{*}t')),
         'type':val(bar,'barDir'),'refs':refs,'categories':categories,'values':[float(x) for x in values],
         'anchor':anchor,'color':'#'+colors[4]}
  pane=sh.find('{*}sheetViews/{*}sheetView/{*}pane')
  return {'cols':cols,'rowHeights':hh,'cells':cs,'styles':styles,'merges':[x.get('ref') for x in sh.findall('.//{*}mergeCell')],'chart':chart,
          'freeze':dict(pane.attrib) if pane is not None else {},'theme':theme.get('name')}
if __name__=='__main__':
 print(json.dumps(make_model(sys.argv[1]),ensure_ascii=False))
