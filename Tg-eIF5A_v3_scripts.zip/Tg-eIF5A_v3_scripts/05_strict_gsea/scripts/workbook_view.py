from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import json
import re
from sheet_reader import R, cells, make_model, make_styles, rmap, shared, xml

ERROR = re.compile(r'#REF!|#DIV/0!|#VALUE!|#NAME\?|#N/A')
LAYOUT = json.loads(Path(__file__).with_name('layout.json').read_text(encoding='utf-8'))


def column_index(name):
    value = 0
    for letter in name:
        value = 26*value + ord(letter) - 64
    return value-1


def coordinates(address):
    match = re.fullmatch(r'([A-Z]+)([0-9]+)', address)
    return column_index(match[1]), int(match[2])-1


def one_cell(element, strings):
    kind = element.get('t','n')
    v = element.findtext('{*}v')
    if kind == 's':
        v = strings[int(v)]
    elif kind == 'inlineStr':
        v = ''.join(i.text or '' for i in element.findall('.//{*}t'))
    return {'v':v, 'type':kind, 'f':element.findtext('{*}f'), 'style':int(element.get('s',0))}


def scan_workbook(book, collect_views=False):
    hits, views = [], {}
    with ZipFile(book) as z:
        paths = rmap(z,'xl/workbook.xml')
        strings = shared(z)
        styles = make_styles(xml(z,'xl/styles.xml')) if collect_views else []
        for sheet in xml(z,'xl/workbook.xml').findall('.//{*}sheet'):
            name = sheet.get('name')
            spec = LAYOUT.get(name) if collect_views else None
            if spec:
                bounds = spec['preview']['range'].split(':')[-1]
                last_col,last_row = coordinates(bounds)
                model = {'cols':[8.43]*(last_col+1),'rowHeights':[15]*(last_row+1),'cells':{},
                         'styles':styles,'merges':[], 'table':False, 'chart':None,
                         'size':spec['preview']['size'],'colorScales':[]}
            with z.open(paths[sheet.get('{%s}id'%R)]) as part:
                for _, element in ET.iterparse(part,events=('end',)):
                    tag=element.tag.rsplit('}',1)[-1]
                    if tag=='row':
                        row=int(element.get('r'))-1
                        if spec and row<=last_row and element.get('ht'):
                            model['rowHeights'][row]=float(element.get('ht'))
                        for cell in element.findall('{*}c'):
                            address=cell.get('r');current=one_cell(cell,strings)
                            for field in ('v','f'):
                                if ERROR.search(current[field] or ''):
                                    hits.append({'kind':'match','sheet':name,'address':address,'value':current['v'],
                                                 'formula':current['f'],'match': 'value' if field=='v' else 'formula'})
                                    break
                            if spec and row<=last_row and coordinates(address)[0]<=last_col:
                                model['cells'][address]=current
                        element.clear()
                    elif spec and tag=='col':
                        for c in range(int(element.get('min'))-1,min(int(element.get('max')),last_col+1)):
                            model['cols'][c]=float(element.get('width'))
                    elif spec and tag=='mergeCell':
                        model['merges'].append(element.get('ref'))
                    elif spec and tag=='tablePart':
                        model['table']=True
                    elif spec and tag=='conditionalFormatting':
                        scale=element.find('.//{*}colorScale')
                        if scale is not None:
                            model['colorScales'].append({'range':element.get('sqref'),
                                'colors':[e.get('rgb')[-6:] for e in scale.findall('{*}color')],
                                'middle':float(scale.findall('{*}cfvo')[1].get('val','0'))})
            if spec:
                if name=='Summary':
                    model['chart']=make_model(book)['chart']
                views[name]=model
    return hits, views


def inspect_summary(model):
    values=[]
    for r in range(1,28):
        row=[]
        for c in range(13):
            cell=model['cells'].get(f'{chr(65+c)}{r}',{})
            value=cell.get('v')
            if value is not None and cell['type']=='n':
                value=int(value) if re.fullmatch(r'[+-]?\d+',value) else float(value)
            row.append(value)
        values.append(row)
    return {'kind':'table','sheet':'Summary','address':'A1:M27','rows':27,'cols':13,'values':values}


def notice():
    return {'kind':'notice','message':'Cell search matched 0 entries.'}
